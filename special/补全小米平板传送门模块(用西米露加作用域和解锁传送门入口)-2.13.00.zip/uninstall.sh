# shellcheck disable=SC2148
MODDIR=${0%/*}

# 删除模块
rm -rf "$MODDIR"
