# HyperOS For Pad 传送门补丁

## 模块简介

本Magisk模块用于修复Hyper OS For Pad 有关 [传送门] 相关的系统应用权限，并为小米平板补全传送门。

## 模块该怎么使用？

本Magisk模块需使用[Hyper Ceiler]或者[创建快捷方式]开启传送门相关配置，传送门系统UI界面位于[设置-更多设置-传送门]内。

传送门Apk下载:

链接:  https://caiyun.139.com/m/i?135ClTgdI5mRV

创建快捷方式:

链接:  https://caiyun.139.com/m/i?135Cm7bBJVOQv

HyperCeiler下载:

链接:  https://cemiuiler.sevtinge.cc/Download.html

## 许可协议

《HyperOS For Pad 传送门补丁》允许个人在非盈利用途下的安装和使用本Magisk模块，禁止用于任何商业性或其他未经许可的用途，作为项目的主要维护者将保留对项目的所有权利。


